import random
import time

#print('press enter two times to finish this code')
c = input("Enter text (or Enter to quit): ")
# first input
list1= []

while True :
  if not c:
        break
  list1.append(c)
  print(list1[random.randint(0,len(list1)-1)])
  # print one of your previous input

  c = input("Enter text (or Enter to quit): ")
  # input until press twice enter

time.sleep(5) #stop 5 seconds